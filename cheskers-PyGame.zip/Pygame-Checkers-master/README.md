Pygame-Checkers
===============

GitHub repository for an individual project in Python for Programming Workshop at Marlboro College. The goal was to create a fully functional checkers engine for two players.

User should install pygame 1.9.2 release for required libraries. 
